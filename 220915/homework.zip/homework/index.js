const title = document.getElementById("title");

let smallCircle = document.getElementById("small-circle");
const startButton = document.getElementById("start-button");

let money = 1000;

startButton.addEventListener("click", function () {
  let pTag = document.createElement("p");
  pTag.innerText = `coin : ${money} `;

  title.appendChild(pTag);
});
